# Bounce Back: Fractured (Godot 4.2+)

Open `project.godot` in Godot 4.2 or newer and press F5. No assets needed: everything is drawn
with placeholder shapes and the audio is generated in code.

## Controls
| Key | Action |
|---|---|
| A / D or arrows | Move |
| Space / W / Up | Jump |
| E | Interact |
| Q | Echo (after you find it) |
| R | Recollection (after you find it) |
| Enter | Start / play again |

## Walkthrough (about 5 minutes)
1. **Ballroom**: wind the music box (E), then open the door.
2. **Gallery**: take the Echo orb. Press Q near the pit to reveal stepping stones, cross, then Q near the
   far wall to reveal the hidden door and open it.
3. **Corridor**: take the Recollection orb. Press R at the broken bridge, cross, then open the door with the red knob.
4. **Forgotten Room**: the Watcher encounter triggers as you walk in. Press Q near the three objects: dots
   show the order (1, 2, 3). Touch them in that order to recover the memory. Then press R at the broken
   stairs, Q at the top to reveal the exit door, and go through it.

Falling shows "Bounce back." and respawns you at the last checkpoint.

## Files
| File | Role |
|---|---|
| `main.gd` | Level layout, progression, puzzles, Watcher encounter, UI, audio mixing, ending |
| `player.gd` | Movement, coyote time, jump buffer, Echo and Recollection casting |
| `solid.gd` | Collision blocks: normal, HIDDEN (Echo) and BROKEN (Recollection) |
| `interactable.gd` | Orbs, doors, music box, memory objects, exit |
| `watcher.gd` | The silhouette |
| `backdrop.gd` | Placeholder art for all four areas and the environmental anomalies |
| `pulse.gd` | Ability ring and light effect |
| `sounds.gd` | Generated placeholder audio |
| `palette.gd` | All colours, in one place |

## Tuning (all constants at the top of each file)
- Ability radius and duration: `player.gd` (`ECHO_*`, `RECOLLECT_*`).
- Jump and speed: `player.gd`. Gaps are tuned to about 70px max so you can't fail by a pixel.
- Darkness per area: `AREA_MOD`, `AREA_LIGHT_*` in `main.gd`. Make the Forgotten Room brighter if it is too dark on your monitor.
- Level geometry, hints and checkpoints: `_build_level()` in `main.gd`.

## Person 2: dropping in real art and audio
- **Palette**: edit `palette.gd`.
- **Player**: replace `_draw()` in `player.gd` with an `AnimatedSprite2D` child. The origin is the feet.
- **Floors and platforms**: `Solid` draws rectangles in `_draw_normal()`. Use a `TileMapLayer` for the visuals and keep `Solid` for collision.
- **Backgrounds**: replace the functions in `backdrop.gd` with `Sprite2D` or `ParallaxBackground` nodes.
- **Audio**: in `_build_audio()` in `main.gd`, swap `Sounds.xxx()` for `load("res://audio/xxx.ogg")`.

## Not included
The optional REBOUND ability. Easiest way to add it: a third `has_rebound` flag in `player.gd` that sets
`velocity.y = -650` once while airborne.

## Export
Project > Export > add Web or Windows. For Web, audio starts only after the first key press (Enter on the title screen), which satisfies browser autoplay rules.
